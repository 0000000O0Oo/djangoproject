from django.shortcuts import render, redirect
from django.http import HttpResponse, Http404
from datetime import datetime
from strains.models import Weed

# Create your views here.

def weed(request):
	return render(request, "strains/index.html", locals())

def accueil(request):
	sortes = Weed.objects.all()
	return render(request, 'strains/index.html', {'sortes':sortes})

def lire(request):
	pass

def aaaaa(request):
	return render(request, 'strains/aaaaa.html', {'getsortes':Weed.objects.filter(categorie=1), 'allcat':Weed.objects.all()})