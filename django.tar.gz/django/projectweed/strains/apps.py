from django.apps import AppConfig


class StrainsConfig(AppConfig):
    name = 'strains'
