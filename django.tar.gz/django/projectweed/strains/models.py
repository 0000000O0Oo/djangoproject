from django.db import models
from django.utils import timezone

# Create your models here.

class Categorie(models.Model):
    nom = models.CharField(max_length=25)
    
    def __str__(self):
        return self.nom

class Weed(models.Model):
    name = models.CharField(max_length=75)
    titre = models.CharField(max_length=60)
    straintype = models.CharField(max_length=30)
    quote = models.FloatField()
    thc = models.FloatField()
    disponible = models.BooleanField()
    description = models.TextField()
    prix = models.FloatField()
    categorie = models.ForeignKey('Categorie', on_delete=models.CASCADE)
    pic = models.ImageField(upload_to='images/', null=True, blank=True)

    def get_image(self):
    	if self.pic and hasattr(self.pic, 'url'):
    		return self.pic.url
    	else:
    		return '/media/images/default.jpg'
    
    def __str__(self):
        
        
        return self.titre